<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\2. Web Dev\20. TA UKS\Backend-Unit-Kesehatan-Sekolah\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>