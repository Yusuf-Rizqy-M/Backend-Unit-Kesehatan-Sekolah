<?php echo e($slot); ?>

<?php /**PATH D:\2. Web Dev\20. TA UKS\Backend-Unit-Kesehatan-Sekolah\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>